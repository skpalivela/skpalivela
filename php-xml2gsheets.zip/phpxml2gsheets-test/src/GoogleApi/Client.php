<?php 
namespace GoogleSheetsConverter\GoogleApi;

use Google_Client;
use GoogleSheetsConverter\Table\Table;

final class Client
{
    private ?array $accessToken = null;
    private Google_Client $wrappedClient;

    private const AUTH_CONFIG_FILE = __DIR__ . '/config/credentials.json';

    private const CLIENT_SCOPES = [
        \Google_Service_Sheets::SPREADSHEETS,
        \Google_Service_Oauth2::USERINFO_EMAIL,
        \Google_Service_Oauth2::USERINFO_PROFILE,
    ];

    public function __construct(string $authConfigFile = self::AUTH_CONFIG_FILE)
    {
        $client = new Google_Client();
        $client->setAccessType('offline');
        $client->setAuthConfig($authConfigFile);
        $client->setScopes(self::CLIENT_SCOPES);

        $this->wrappedClient = $client;
    }

    public function authenticate(string $authCode): array
    {
        $accessToken = $this->wrappedClient->fetchAccessTokenWithAuthCode($authCode);
        $this->setAccessToken($accessToken);

        return $accessToken;
    }

    public function createAuthUrl(): string
    {
        return $this->wrappedClient->createAuthUrl(self::CLIENT_SCOPES);
    }

    public function createSpreadsheet(Table $table, string $name): string
    {
        $sheetsService = new \Google_Service_Sheets($this->wrappedClient);

        $spreadsheet = $sheetsService->spreadsheets->create(
            new \Google_Service_Sheets_Spreadsheet(
                [
                    'properties' => [
                        'title' => $name,
                    ],
                ],
            ),
        );

        $values = $table->getRows();

        if ($table->hasHeadings()) {
            \array_unshift($values, $table->getHeadings());
        }

        $sheetsService->spreadsheets_values->update(
            $spreadsheet->getSpreadsheetId(),
            'Sheet1!A1',
            new \Google_Service_Sheets_ValueRange(['values' => $values]),
            [
                'valueInputOption' => 'RAW',
            ],
        );

        return $spreadsheet->getSpreadsheetUrl();
    }

    public function requiresAuthentication(): bool
    {
        return $this->accessToken === null;
    }

    public function setAccessToken(array $accessToken) : void
    {
        $this->accessToken = $accessToken;
        $this->wrappedClient->setAccessToken($accessToken);
    }
}
