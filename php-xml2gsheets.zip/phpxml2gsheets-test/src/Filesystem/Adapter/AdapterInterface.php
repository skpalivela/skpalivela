<?php 

namespace GoogleSheetsConverter\Filesystem\Adapter;

interface AdapterInterface
{
    public function loadContents(string $uri): string;

    public function supports(string $uri): bool;
}
