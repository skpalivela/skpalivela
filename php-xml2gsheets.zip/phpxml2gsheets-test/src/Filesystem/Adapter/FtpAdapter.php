<?php 

namespace GoogleSheetsConverter\Filesystem\Adapter;

use GoogleSheetsConverter\Filesystem\Exception\FilesystemError;

final class FtpAdapter implements AdapterInterface
{
    /**
     * @param resource $connection
     * @param string|null $username
     * @param string|null $password
     */
    private function authenticate(
        &$connection,
        ?string $username,
        ?string $password
    ): void
    {
        if (
            isset($username, $password)
            && \ftp_login($connection, $username, $password) === false
        ) {
            throw new FilesystemError(
                \sprintf(
                    'Invalid credentials for user [%s]!',
                    $username,
                )
            );
        }
    }

    
    private function connect(string $host, int $port)
    {
        $conn = \ftp_connect($host, $port);

        if ($conn === false) {
            throw new FilesystemError(
                \sprintf(
                    'Could not connect to FTP host [%s:%s]!',
                    $host,
                    $port,
                )
            );
        }

        return $conn;
    }

    public function loadContents(string $uri): string
    {
        
        $uriParts = \parse_url($uri);

        $host = $uriParts['host'];
        $port = $uriParts['port'] ? (int)$uriParts['port'] : 21;

        $connection = $this->connect($host, $port);

        $this->authenticate(
            $connection,
            $uriParts['user'] ?? null,
            $uriParts['password'] ?? null
        );

        $filePath = $uriParts['path'];
        $tempFile = \fopen('php://temp', 'rb+');

        \ftp_get($connection, $tempFile, $filePath, \FTP_ASCII, 0);

        $tempFileStats = \fstat($tempFile);
        $contents = \fread($tempFile, $tempFileStats['size']);

        \fclose($tempFileStats);
        \ftp_close($connection);

        return $contents;
    }

    public function supports(string $uri): bool
    {
        return \parse_url($uri, \PHP_URL_SCHEME) === 'ftp';
    }
}
