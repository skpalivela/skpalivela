<?php 

namespace GoogleSheetsConverter\Parser\Exception;

final class ParseError extends \RuntimeException
{
    public function __construct(\Throwable $previous)
    {
        parent::__construct(
            \sprintf(
                'error while parsing the file contents: %s.',
                $previous->getMessage()
            ),
            0,
            $previous
        );
    }
}
