<?php 

use DI\ContainerBuilder;
use GoogleSheetsConverter\Command;
use GoogleSheetsConverter\Filesystem\Adapter as FilesystemAdapters;
use GoogleSheetsConverter\Filesystem\Loader as FileLoader;
use GoogleSheetsConverter\Parser;
use Psr\Container\ContainerInterface;
use Symfony\Component\Console\Application as ConsoleApplication;

$container = new ContainerBuilder();
$container->addDefinitions(
    [
        // Params
        'app.name' => 'Google Sheets Converter',
        'app.version' => 'v0.1337',

        // CLI app
        ConsoleApplication::class => static function (ContainerInterface $c) {
            $cli = new ConsoleApplication(
                $c->get('app.name'),
                $c->get('app.version'),
            );

            // Register commands
            $cli->addCommands(
                [
                    $c->get(Command\ConvertCommand::class),
                ],
            );

            return $cli;
        },

        // Supported Parsers
        Parser\Parser::class => static function (ContainerInterface $c) {
            return new Parser\Parser(
                $c->get(Parser\XmlParser::class),                
            );
        },

        // Supported Remote Filesystems
        FileLoader::class => static function (ContainerInterface $c) {
            return new FileLoader(
                $c->get(FilesystemAdapters\FtpAdapter::class),
            );
        },
    ],
);

return $container->build();
