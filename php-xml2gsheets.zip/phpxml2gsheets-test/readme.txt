steps to run program

1. install latest version php
2. install symfony 
3. install symfony console 
   composer require symfony/console
5. google account and turn on the google sheets api at https://developers.google.com/sheets/api/quickstart/php. copy credentials.json to /src/googleapi/config folder
4. update composer.json and run composer update
5. to run console application php index.php parsexml <xmlfile>