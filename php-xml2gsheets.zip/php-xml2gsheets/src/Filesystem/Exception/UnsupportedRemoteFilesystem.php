<?php 

namespace GoogleSheetsConverter\Filesystem\Exception;

final class UnsupportedRemoteFilesystem extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct(
            'remote filesystem is not supported.',
            0,
            null
        );
    }
}
