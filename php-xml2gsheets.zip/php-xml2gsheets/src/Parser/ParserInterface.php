<?php 

namespace GoogleSheetsConverter\Parser;

use GoogleSheetsConverter\Table\Table;

interface ParserInterface
{
    public function parse(string $contents): Table;

    public function supports(string $contents): bool;
}
