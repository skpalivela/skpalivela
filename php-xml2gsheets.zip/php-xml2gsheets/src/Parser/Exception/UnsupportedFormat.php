<?php 

namespace GoogleSheetsConverter\Parser\Exception;

final class UnsupportedFormat extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct(
            'parser unable to determine the file.',
            0,
            null
        );
    }
}
