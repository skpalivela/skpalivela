<?php 

namespace GoogleSheetsConverter\Command;

use GoogleSheetsConverter\Filesystem\Loader;
use GoogleSheetsConverter\GoogleApi\Client as GoogleApiClient;
use GoogleSheetsConverter\Parser\Parser;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Helper\QuestionHelper;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Question\Question;

final class ConvertCommand extends Command
{
    private GoogleApiClient $apiClient;
    private Loader $fileLoader;
    private Parser $parser;

    private const ARG_SHEET_NAME = 'sheet_name';
    private const ARG_SOURCE_FILE = 'source_file';
    private const OPT_GOOGLE_ACCESS_TOKEN = 'google-access-token';

    public function __construct(Loader $fileLoader, GoogleApiClient $apiClient, Parser $parser)
    {
        parent::__construct(null);

        $this->apiClient = $apiClient;
        $this->fileLoader = $fileLoader;
        $this->parser = $parser;
    }

    protected function configure(): void
    {
        // parent::configure() does nothing, so no need to call it
        $this
            ->setName('convert')
            ->setDescription('Fetches the provided file, processes it and uploads it to Google Sheets')
            ->addUsage(<<<USAGE
TODO: Add usage info
USAGE
            )
            // first argument: the (remote) file which should be processed
            ->addArgument(
                self::ARG_SOURCE_FILE,
                InputArgument::REQUIRED,
                'The file which should be processed and uploaded to Google Sheets',
            )
            // second (optional) argument: the name to use for the Google Sheet
            ->addArgument(
                self::ARG_SHEET_NAME,
                InputArgument::OPTIONAL,
                'The target file name to use for the created Google Sheet - defaults to the source filename if omitted',
                null,
            )
            // options
            ->addOption(
                self::OPT_GOOGLE_ACCESS_TOKEN,
                null,
                InputOption::VALUE_REQUIRED,
                'The access token to use when communicating with the Google Sheets API - avoids having to run interactive authentication',
                null,
            );
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        // parent::execute triggers a LogicException because it is meant to be overridden

        // TODO/Cleanup: Wrap in a service class
        // TODO: Stream contents instead of loading entire file into memory
        $file = $input->getArgument(self::ARG_SOURCE_FILE);
        $contents = $this->fileLoader->loadContents($file);

        // Create the tabular data we want to upload to Google Sheets
        $table = $this->parser->parse($contents);

        // Create a new Google Sheet from the tabular data
        $accessToken = $input->getOption(self::OPT_GOOGLE_ACCESS_TOKEN);
        $accessToken = $accessToken ? \json_decode($accessToken, true) : null;

        if ($accessToken) {
            $this->apiClient->setAccessToken($accessToken);
        }

        if ($this->apiClient->requiresAuthentication()) {
            $output->writeln(
                [
                    'Unfortunately, we need to authenticate against the Google Sheets API.',
                    'Please open the following link in your browser:',
                    $this->apiClient->createAuthUrl(),
                    '',
                ]
            );

            $authCode = (new QuestionHelper())
                ->ask($input, $output, new Question('Enter the verification code: '));

            $accessToken = $this->apiClient->authenticate($authCode);

            $output->writeln(
                [
                    '',
                    'Success! ',
                    'when calling this application by using the --' . self::OPT_GOOGLE_ACCESS_TOKEN . ' option.',
                    \json_encode($accessToken),
                ]
            );
        }

        $name = $input->getArgument(self::ARG_SHEET_NAME) ?? \basename($file);
        $spreadsheetUrl = $this->apiClient->createSpreadsheet($table, $name);

        $output->writeln(
            [
                '',
                'Task Completed. view your converted spreadsheet at the following URL:',
                $spreadsheetUrl,
            ]
        );

        return 0;
    }
}
