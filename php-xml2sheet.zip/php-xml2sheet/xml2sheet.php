#!/usr/bin/env php
<?php

require __DIR__ . '/vendor/autoload.php';

use Psr\Container\ContainerInterface;
use Symfony\Component\Console\Application as ConsoleApplication;

/** @var ContainerInterface $container */
$container = require __DIR__ . '/config/container.php';

return $container
    ->get(ConsoleApplication::class)
    ->run();
