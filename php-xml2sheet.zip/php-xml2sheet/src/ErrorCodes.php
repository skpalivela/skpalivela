<?php 

namespace GoogleSheetsConverter;

abstract class ErrorCodes
{
    public const SOMETHING = 1;
}
