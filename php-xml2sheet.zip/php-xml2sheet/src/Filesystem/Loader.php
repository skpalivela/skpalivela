<?php

namespace GoogleSheetsConverter\Filesystem;

use GoogleSheetsConverter\Filesystem\Adapter\AdapterInterface;
use GoogleSheetsConverter\Filesystem\Exception\FilesystemError;
use GoogleSheetsConverter\Filesystem\Exception\UnsupportedRemoteFilesystem;

final class Loader
{
    /** @var AdapterInterface[] */
    private array $adapters;

    public function __construct(AdapterInterface ...$adapters)
    {
        $this->adapters = $adapters;
    }

    private function findAdapter(string $uri): AdapterInterface
    {
        foreach ($this->adapters as $adapter) {
            if ($adapter->supports($uri)) {
                return $adapter;
            }
        }

        throw new UnsupportedRemoteFilesystem();
    }

    public function loadContents(string $file): string
    {
        // No need for an adapter if the file is a local one
        if (\strpos($file, '://') === false) {
            if (\realpath($file) === false || \file_exists($file) === false) {
                throw new FilesystemError(
                    \sprintf(
                        'Unable to resolve local file [%s], it might not exist.',
                        $file
                    )
                );
            }

            try {
                return \file_get_contents($file);
            } catch (\Throwable $ex) {
                throw new FilesystemError($ex->getMessage(), 0, $ex);
            }
        }

        // Try to find a matching remote FS adapter
        // to load the contents of the file
        return $this
            ->findAdapter($file)
            ->loadContents($file);
    }
}
