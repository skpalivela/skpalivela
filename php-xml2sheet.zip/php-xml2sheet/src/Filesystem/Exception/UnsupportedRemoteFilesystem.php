<?php 

namespace GoogleSheetsConverter\Filesystem\Exception;

final class UnsupportedRemoteFilesystem extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct(
            'The filesystem is not supported.',
            0,
            null
        );
    }
}
