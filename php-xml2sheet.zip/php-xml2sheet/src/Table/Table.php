<?php 

namespace GoogleSheetsConverter\Table;

final class Table
{
    private array $headings = [];

    private int $rowCount = 0;
    private array $rows = [];

    public function addRow(array $row): void
    {
        $this->rowCount++;
        $this->rows[] = \array_values($row);
    }

    public function getHeadings(): array
    {
        return $this->headings;
    }

    public function getRowCount(): int
    {
        return $this->rowCount;
    }

    public function getRows(): array
    {
        return $this->rows;
    }

    public function hasHeadings(): bool
    {
        return \count($this->headings) > 0;
    }

    public function setHeadings(array $headings): void
    {
        $this->headings = \array_values($headings);
    }
}
