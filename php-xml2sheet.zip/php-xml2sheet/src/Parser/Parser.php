<?php 

namespace GoogleSheetsConverter\Parser;

use GoogleSheetsConverter\Parser\Exception;
use GoogleSheetsConverter\Table\Table;

final class Parser
{
    /** @var ParserInterface[] */
    private array $parsers;

    public function __construct(ParserInterface ...$parsers)
    {
        $this->parsers = $parsers;
    }

    public function parse(string $contents): Table
    {
        
        $contents = \trim($contents);

        // Determine the parser we should use and have it parse the contents for us
        foreach ($this->parsers as $parser) {
            if ($parser->supports($contents)) {
                try {
                    return $parser->parse($contents);
                } catch (\Throwable $ex) {
                    throw new Exception\ParseError($ex);
                }
            }
        }

        // Unsupported File Format
        throw new Exception\UnsupportedFormat();
    }
}
