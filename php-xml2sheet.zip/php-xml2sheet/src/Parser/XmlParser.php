<?php 

namespace GoogleSheetsConverter\Parser;

use GoogleSheetsConverter\Parser\Exception\ParseError;
use GoogleSheetsConverter\Table\Table;


final class XmlParser implements ParserInterface
{
    public function parse(string $contents): Table
    {
        try {
            $data = \simplexml_load_string($contents);
        } catch (\Throwable $ex) {
            throw new ParseError($ex);
        }

        if ($data->children()->count() === 0) {
            return new Table();
        }

        // level element to be a collection
        $headings = [];
        $table = new Table();

        foreach ($data->children() as $item) {
            $row = [];

            foreach ($item->children() as $i => $property) {
                $propertyName = $property->getName();
                $row[$propertyName] = (string)$property;

                // Add the property to the headings map
                if (!isset($headings[$propertyName])) {
                    $headings[$propertyName] = $i;
                }
            }

            $table->addRow($row);
        }

        $table->setHeadings(\array_keys($headings));

        return $table;
    }

    public function supports(string $contents): bool
    {
        return (\strpos(\trim($contents), '<?xml') === 0);
    }
}
