<?php

namespace GoogleSheetsConverter\Parser\Exception;

final class UnsupportedFormat extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct(
            'parser not able to determine the file type.',
            0,
            null
        );
    }
}
