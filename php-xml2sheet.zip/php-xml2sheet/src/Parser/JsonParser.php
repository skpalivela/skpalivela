<?php 

namespace GoogleSheetsConverter\Parser;

use GoogleSheetsConverter\Table\Table;

/**
 * @internal Use GoogleSheetsConverter\Parser\Parser instead
 */
final class JsonParser implements ParserInterface
{
    public function parse(string $contents): Table
    {
        $data = \json_decode($contents, true, 512, \JSON_THROW_ON_ERROR);

        $firstItem = \reset($data);
        if ($firstItem === false) {
            return new Table();
        }

        // If our items are a list we ignore headings
        \ksort($firstItem);
        $collectHeadings = ($firstItem !== \array_values($firstItem));

        // TODO: This naively assumes the top level element to be a collection
        $headings = [];
        $table = new Table();

        foreach ($data as $item) {
            $row = [];

            foreach ($item as $propertyName => $value) {
                $row[$propertyName] = $value;

                // Add the property to the headings map
                if ($collectHeadings && !isset($headings[$propertyName])) {
                    $headings[$propertyName] = \count($headings);
                }
            }

            $table->addRow($row);
        }

        $table->setHeadings(\array_keys($headings));

        return $table;
    }

    public function supports(string $contents): bool
    {
        return (\strpos(\trim($contents), '{') === 0);
    }
}
